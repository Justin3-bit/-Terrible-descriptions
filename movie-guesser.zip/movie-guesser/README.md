# Movie Guesser App

A fun React app where you guess movies from terrible plot descriptions.

## Project Structure

```
movie-guesser/
├── src/
│   ├── components/
│   │   └── MovieGuesser.jsx    # Main component
│   ├── data/
│   │   └── movies.js            # Movie data (add your movies here!)
│   ├── styles/
│   │   └── MovieGuesser.css     # All styles
│   ├── App.jsx                  # Root component
│   └── main.jsx                 # Entry point
├── index.html
├── package.json
├── vite.config.js
└── .gitignore
```

## Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the development server:**
   ```bash
   npm run dev
   ```

3. **Open your browser:**
   - The app will be running at `http://localhost:5173`

## Adding More Movies

Edit `src/data/movies.js` and add new objects to the array:

```js
{
  id: 9,
  title: "Your Movie Title",
  terriblePlot: "Your terrible plot description here",
  image: "URL to poster image",
  year: 2024,
}
```

## Building for Production

```bash
npm run build
```

The built files will be in the `dist/` folder, ready to deploy!

## Deploying to GitHub Pages / Vercel / Netlify

1. Push your code to GitHub
2. Connect your repo to Vercel or Netlify
3. Deploy with one click!
