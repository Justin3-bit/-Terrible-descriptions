import MovieGuesser from "./components/MovieGuesser";

function App() {
  return <MovieGuesser />;
}

export default App;
